using System;

namespace CheyenneHarbarth.Week08.Test
{
    public abstract class Medium
    {
        internal string Titel { get; set; }
        internal string Author { get; set; }
        internal string ReleaseYear { get; set; }
        internal string ISBN { get; set; }
    }
}