public interface ILibrary {
  
}