using System;
namespace NicoDobler.Weke08
{
        public class Bibliothek
        {

            private List<Medium> medien;

            public Bibliothek()
            {
                medien = new List<Medium>();
            }

            public void Add(Medium medium)
            {
                medien.Add(medium);
            }


        }

        public void Entfernen(Medium medium){

            medium.Entfernen(medium);
        }

        public void Anzeigen(Medium medium){
            foreach (var Medium in medien){

            }

        }

       

    }
    

